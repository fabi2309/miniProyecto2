import { DomseguroPipe } from './domseguro.pipe';

describe('DomseguroPipe', () => {
  it('create an instance', () => {
    const pipe = new DomseguroPipe();
    expect(pipe).toBeTruthy();
  });
});
